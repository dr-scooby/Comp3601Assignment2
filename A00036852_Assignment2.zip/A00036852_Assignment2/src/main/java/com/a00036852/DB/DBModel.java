/**
 * Assignment 2
 * @author Jahangir Ismail
 * DBModel handles the Database connection, driver, url settings
 */
package com.a00036852.DB;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DBModel {
	
	private String derbydbdriver = "org.apache.derby.jdbc.EmbeddedDriver";				
	private String derbydburl= "jdbc:derby:derby_jdbc_test;create=true";
	private String dbuser = "admin";
	private String dbpassword = "admin";

	// Connection
	private Connection con;
	
	/**
	 * default Constructor
	 */
	public DBModel() {
		// try to load DB driver
		try {
			Class.forName(derbydbdriver);
		}catch(ClassNotFoundException ce) {
			ce.printStackTrace();
		}
		
		try {
			con = DriverManager.getConnection(derbydburl, dbuser, dbpassword);
		}catch(SQLException sq) {
			sq.printStackTrace();
		}
	}
	
	/**
	 * Get DB properties
	 * @param driver String
	 * @param url String
	 * @param user String
	 * @param pass String
	 */
	public DBModel(String driver, String url, String user, String pass) {
		this.derbydbdriver = driver;
		this.derbydburl = url;
		this.dbuser = user;
		this.dbpassword = pass;
		
		try {
			Class.forName(derbydbdriver);
		}catch(ClassNotFoundException ce) {
			ce.printStackTrace();
		}
		
		try {
			con = DriverManager.getConnection(derbydburl, dbuser, dbpassword);
		}catch(SQLException sq) {
			sq.printStackTrace();
		}
	}

	/**
	 * get the database Connection
	 * @return Connection
	 */
	public Connection getConnection() {
		return con;
	}
	
	/**
	 * close the DB connection
	 */
	public void close() {
		try {
			con.close();
		}catch(SQLException s) {
			s.printStackTrace();
		}
	}
	
	// load Database driver for derby
		private void loadDriver() {
			try {
				Class.forName(derbydbdriver);
			}catch(ClassNotFoundException c) {
				c.printStackTrace();
			}
		}
	
	/**
	 * connect to DB
	 */
	public void connect() {
		// check if connection is null
		if(con == null) {
			
			loadDriver(); // load driver, otherwise Connection wont work.
		}
		try {
		 con = DriverManager.getConnection(derbydburl, dbuser, dbpassword);
		 //System.out.println("Database connected");
		}catch(SQLException s) {
			s.printStackTrace();
		}
		
	}
	
	// create a table
	/**
	 * create a table
	 * @param sql String
	 */
	public void creatTable(String sql) {
		//System.out.println("\nDatabase.createTable() called..\n");
		connect(); // connect to DB, may have been closed
		
		try {
			Statement state = con.createStatement();
			state.executeUpdate(sql) ;
				//System.out.println("Create Table success :> " + sql);
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * insert into
	 * @param sql String
	 */
	public void insert(String sql) {
		//System.out.println("\nDatabase.insert() called..");
		connect(); // connect to DB, may have been closed
		
		try{
			
			Statement st = con.createStatement();
			st.executeUpdate(sql) ;
				//System.out.println("insert success");
		
		}catch(SQLException s) {
			s.printStackTrace();
		}
	}
	
	/**
	 * Drop table from DB
	 * @param t String name of table
	 * @throws SQLException
	 */
	public void dropTable(String t)throws SQLException {
		connect();
		
		try {
			Statement st = con.createStatement();
			st.execute("drop table " + t);
		}catch(SQLException s) {
			s.printStackTrace();
		}
	}
	
	/**
	 * Check if table exists
	 * @param targetTableName String
	 * @return boolean true if exists, false if doens't exist
	 * @throws SQLException
	 */
	public boolean tableExists(String targetTableName) throws SQLException {
		DatabaseMetaData databaseMetaData = con.getMetaData();
		ResultSet resultSet = null;
		String tableName = null;

		try {
			resultSet = databaseMetaData.getTables(con.getCatalog(), "%", "%", null);
			while (resultSet.next()) {
				tableName = resultSet.getString("TABLE_NAME");
				if (tableName.equalsIgnoreCase(targetTableName)) {
					return true;
				}
			}
		} finally {
			resultSet.close();
		}

		return false;
	}
}
