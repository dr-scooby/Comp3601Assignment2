/**
 * Data Access Object class
 * @author Jahangir Ismail
 * Assignment 2
 */
package com.a00036852.dao;

import java.sql.SQLException;

import com.a00036852.DB.DBModel;


public abstract class DAO {
	
	protected final String tablename;
	
	protected DBModel dbmodel; // handle to the Database Model
	
	
	/**
	 * Default Constructor
	 */
	protected DAO(){
		tablename = "";
		
		//dbmodel = new DBModel();
	}
	
	/**
	 * Contructor takes DBModel
	 * @param d DBModel
	 */
	protected DAO(DBModel d){
		tablename = "";
		this.dbmodel = d;
	}
	
	/**
	 * 
	 * @param db DBModel
	 * @param table String
	 */
	protected DAO(DBModel db, String table){
		this.tablename = table;
		this.dbmodel = db;
	}
	

	/**
	 * abstract method create
	 * @throws SQLException
	 */
	public abstract void create() throws SQLException ;
	
	
	
	/**
	 * create a Table using an sql statement
	 * @param sql SQL statement
	 * @throws SQLException
	 */
	protected void create(String sql) throws SQLException {
		//System.out.println("in DAO, create: " + sql);
		dbmodel.creatTable(sql);
		
	}
	
	
	/**
	 * add Object to the DB
	 * @param sql String SQL
	 * @throws SQLException
	 */
	protected void add(String sql) throws SQLException {
		
		//System.out.println("in DAO, add: " + sql);
		dbmodel.insert(sql);
		
	}
}
