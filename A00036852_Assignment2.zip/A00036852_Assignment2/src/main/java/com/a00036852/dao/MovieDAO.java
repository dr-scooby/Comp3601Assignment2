/**
 * Movie Data Access Object
 * @author Jahangir Ismail
 * Assignemnt 2
 */
package com.a00036852.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.a00036852.DB.DBModel;
import com.a00036852.data.Movie;


public class MovieDAO extends DAO{

	//private DBModel db;
	
	
	/**
	 * Get a DBModel handle
	 * @param d DBModel
	 */
	public MovieDAO(DBModel d) {
		super(d);
		
	}
	
	/**
	 * 
	 * @param d DBModel
	 * @param table String
	 */
	public MovieDAO(DBModel d, String table) {
		super(d, table);
	}
	
	
	
	/**
	 * create the Table Movie
	 */
	public void create()throws SQLException{
		// hard code the table name for now, testing
		String create_table = 
				"create table movie (id int not null primary key generated always as identity (start with 1, increment by 1), Title varchar(100), yearofrelease varchar(15), runtime varchar(20), story varchar(200))";
		
		super.create(create_table);
	}
	
	
	/**
	 * Add a Movie to the DB
	 * @param m Movie
	 * @throws SQLException
	 */
	public boolean addMovie(Movie m)throws SQLException{
		boolean ok = false; // set to false
		// get a DB connection
		Connection con = dbmodel.getConnection();
		// check if movie already exists, search by Title
		String sql_find = "select count(*) from movie where Title=?";
//		PreparedStatement ps = con.prepareStatement(sql_find);
//		ps.setString(1, m.getTitle());
//		ResultSet rs = ps.executeQuery();
//		rs.next();
//		String counts = rs.getString(1);
		//if(counts.equals("0")) { // nothing found
		if( !dbmodel.tableExists("movie")) {
			create();
		}
			String sql_insert = "insert into movie ( Title, yearofrelease ) values( 'Episode IV  A New Hope', 'May 25, 1977' )";
			String sql = "insert into movie(Title, yearofrelease, runtime, story) values(?, ?, ?, ?)";
			
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, m.getTitle());
			pst.setString(2, m.getYearofrelease());
			pst.setString(3, m.getRuntime());
			pst.setString(4, m.getStory());
			
			ok = pst.executeUpdate() > 0;
//		}else {
//			ok = false;
//		}
		
		
		return ok;
		//dbmodel.insert(sql_insert);
		//stat.executeUpdate(insert);
		
	}
	
	// find movie by movie Title
	/**
	 * 
	 * @param t String Title
	 * @return boolean True if found, false if not found
	 * @throws SQLException
	 */
	public boolean findMovie(String t) throws SQLException {
		Movie m = null;
		boolean found = false;
		
		Connection con = dbmodel.getConnection();
		
		String find_sql = "select * from movie where Title =?";
		
		PreparedStatement ps = con.prepareStatement(find_sql);
		ps.setString(1, t);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			String title = rs.getString("Title");
			if(t.equals(title)) {
				System.out.println("Title to search: " + t + " found in DB: " + title);
				found = true;
				m = new Movie(title, rs.getString("yearofrelease"), rs.getString("runtime"), rs.getString("story"));
				break; // the movie title exists in DB, break
			}
		}
		
		if(found)
			System.out.println("Found movie in DB " + m.getTitle());
		else
			System.out.println("NOT found in DB " + t);
		
		return found;
	}
	
	/**
	 * Update the Movie
	 * @param m Movie
	 * @return boolean true if update success, false if update failed
	 * @throws SQLException
	 */
	public boolean update(Movie m) throws SQLException {
		boolean ok = false;
		
		String sql = "update movie set Title=?, yearofrelease=?, runtime=?, story=?  where id=?";
		Connection con = dbmodel.getConnection();
		
		PreparedStatement pst = con.prepareStatement(sql);
		pst.setString(1, m.getTitle());
		pst.setString(2, m.getYearofrelease());
		pst.setString(3, m.getRuntime());
		pst.setString(4, m.getStory());
		pst.setInt(5, m.getId());
		ok = pst.executeUpdate() > 0;
				
		return ok;
	}
	
	
	/**
	 * Delete a movie from the DB
	 * @param m Movie
	 * @return boolean true if update success, false if update failed
	 * @throws SQLException
	 */
	public boolean delete(Movie m)throws SQLException{
		boolean ok = false;
		
		String sql = "delete from movie where id=?";
		Connection con = dbmodel.getConnection();
		PreparedStatement pst = con.prepareStatement(sql);
		pst.setInt(1, m.getId());
		ok = pst.executeUpdate() > 0;
		
		return ok;
	}
	
	/**
	 * get a listing of all Movies from the DB
	 * @return ArrayList<Movie>
	 * @throws SQLException
	 */
	public ArrayList<Movie> getMovies() throws SQLException{
		// init the arraylist
		ArrayList<Movie> movies = new ArrayList<Movie>();
		
		Connection con = dbmodel.getConnection();
		if(con != null) {
			System.out.println("Connection not null getMovies line 68 ");
			String sql = "select * from movie";
			Movie m = null;
			String title, year, runtime, story = "";
			int id ;
			//PreparedStatement ps = con.prepareStatement(sql);
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				id = rs.getInt("id");
				title = rs.getString("Title");
				year = rs.getString("yearofrelease");
				runtime = rs.getString("runtime");
				story = rs.getString("story");
				m = new Movie(title, year, runtime, story);
				m.setId(id);
				movies.add(m);
			}
		}
		
		return movies;
		
	}
}
