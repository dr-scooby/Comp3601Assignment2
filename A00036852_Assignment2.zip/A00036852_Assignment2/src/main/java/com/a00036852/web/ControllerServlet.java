/**
 * ServletController class
 * Assignment 2
 * Student ID: A00036852
 * Student Name: Jahangir Ismail
 */

package com.a00036852.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.a00036852.DB.DBModel;
import com.a00036852.dao.MovieDAO;
import com.a00036852.data.Movie;

/**
 * Servlet implementation class ControllerServlet
 */
//@WebServlet("/ControllerServlet")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private DBModel db; // handle to the DBModel
	
	private MovieDAO md ; // one MovieDAO object
	
	private String page_title;
	
	private String movie_table;
	
	private String AddInstructions;
	
	private String derbydbdriver;
	
	private String derbydburl;
	
	private String dbuser;
	private String dbpass;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public void init() {
    	//db = new DBModel(); // doesn't work here, get SQL errors loading
    	// get the Init Params from the web.xml
		movie_table = getServletConfig().getInitParameter("table_movie");
		// Page_Title
		page_title = getServletConfig().getInitParameter("Page_Title");
		// add instructions
		AddInstructions = getServletConfig().getInitParameter("AddInstructions");
		
		derbydbdriver = getServletConfig().getInitParameter("derbydbdriver");
		
		derbydburl = getServletConfig().getInitParameter("derbydburl");
		
		dbuser = getServletConfig().getInitParameter("dbuser");
		dbpass = getServletConfig().getInitParameter("dbpassword");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		// create DBModel 
		db = new DBModel(derbydbdriver, derbydburl, dbuser, dbpass);
		md = new MovieDAO(db);
		//dropTable();
		try {
			if( !db.tableExists("movie")) {
				md.create();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// get the action from request, add, update, delete
		String action = request.getServletPath();
		System.out.println("Action: " + action);
		if(action.equals("/index.jsp")) {
			System.out.println("index.jsp called");
		}
		
		if(action.equals("/main")) {
		
			try {
				ArrayList<Movie> movies = md.getMovies(); // get a listing
				if(movies.isEmpty()) {
					String empty = "is empty";
					request.setAttribute("isempty", empty);
				}else {
					String empty = "not empty";
					request.setAttribute("isempty", empty);
				}
					
				request.setAttribute("movieslisting", movies); // set movies to the attribute
//				request.setAttribute("page_title", page_title );
//				request.setAttribute("addinstructions", AddInstructions);
				RequestDispatcher disp = request.getRequestDispatcher("index.jsp");
				//disp.include(request, response);
				disp.forward(request, response);
				return;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
		}
		
		// add movie to the DB
		if(action.equals("/addmovie")) {
			try {
				String message = "";
			if( addMovie(request, response))
				message = "Success adding to DB";
			else
				message = "failed to add Movie to DB, Title already exists";
			
			ArrayList<Movie> movies = md.getMovies(); // get listing of all movies
				request.setAttribute("movieslisting", movies); // set movies to the attribute
				request.setAttribute("message", message);
//				request.setAttribute("page_title", page_title );
//				request.setAttribute("addinstructions", AddInstructions);
				RequestDispatcher disp = request.getRequestDispatcher("index.jsp");
				//disp.include(request, response);
				disp.forward(request, response);
				return;
			}catch(SQLException s) {
				System.out.println("Error adding movie:\n" +  s );
			}
		}
		
		// perform update operation
		if(action.equals("/update")) {
			System.out.println("\nUpdate called");
			try {
				update(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		// delete the movie
		if(action.equals("/delete")) {
			System.out.println("\nDelete Called");
			try {
				delete(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	/**
	 * Add Movie to the DB
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 */
	private boolean addMovie(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		boolean ok = false;
		// get parameters from the request
		String title = request.getParameter("movietitle");
		String year = request.getParameter("year");
		String runtime = request.getParameter("runtime");
		String story = request.getParameter("story");
		
		System.out.println("Movie Title: " + title );
		System.out.println("Year: " + year);
		System.out.println("Runtime: " + runtime);
		System.out.println("Story: " + story);
		
		Movie m = new Movie(title, year, runtime, story);
		//md = new MovieDAO(db);
		boolean mfind = md.findMovie(title); // find movie by title, so we don't add 2 movies
		if( !mfind) {
			if( md.addMovie(m)) { // add to DB
				System.out.println("added to db");
				ok = true;
			}	
		}
		return ok;
		
	}// end addMovie
	
	
	/**
	 * Update the Movie with new values
	 * @param request
	 * @param response
	 * @throws IOException 
	 * @throws ServletException 
	 * @throws SQLException 
	 */
	private void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		// get parameters from the request
		String id = request.getParameter("id");
		String title = request.getParameter("movietitle");
		String year = request.getParameter("year");
		String runtime = request.getParameter("runtime");
		String story = request.getParameter("story");
		
		System.out.println("ID: " + id);
		System.out.println("Movie Title: " + title );
		System.out.println("Year: " + year);
		System.out.println("Runtime: " + runtime);
		System.out.println("Story: " + story);
		
		// convert the String id to int
		int x = Integer.parseInt(id.strip());
		System.out.println("the x: " + x);
		
		Movie m = new Movie(title, year, runtime, story);
		m.setId(x);
		
		String message = "";
		
		try {
			if(md.update(m)) {
				System.out.println("Success updating DB");
				message = "Success updating info ";
			}else {
				System.out.println("Failed to update DB");
				message = "Failed to update info ";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ArrayList<Movie> movies = md.getMovies(); // get listing of all movies
		request.setAttribute("movieslisting", movies); // set movies to the attribute
		
		request.setAttribute("message", message);
//		request.setAttribute("page_title", page_title );
//		request.setAttribute("addinstructions", AddInstructions);
		RequestDispatcher disp = request.getRequestDispatcher("index.jsp");
		disp.forward(request, response);
		return;
	}
	
	// delete movie from DB
	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		// get parameters from the request
		String id = request.getParameter("id");
		String title = request.getParameter("movietitle");
		String year = request.getParameter("year");
		String runtime = request.getParameter("runtime");
		String story = request.getParameter("story");
		
		// convert the String id to int
		int x = Integer.parseInt(id.strip());
		
		System.out.println("the x to delete: " + x);
		
		Movie m = new Movie(title, year, runtime, story);
		m.setId(x);
		
		System.out.println("ID: " + id);
		System.out.println("Movie Title: " + title );
		System.out.println("Year: " + year);
		System.out.println("Runtime: " + runtime);
		System.out.println("Story: " + story);
		
		String message = "";
		
		try {
			if(md.delete(m)) {
				System.out.println("Deleted movie from DB");
				message = "Delete Success";
			}else {
				System.out.println("Failed to delete from DB");
				message = "Failed to delete";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ArrayList<Movie> movies = md.getMovies(); // get listing of all movies
		request.setAttribute("movieslisting", movies); // set movies to the attribute
		
		request.setAttribute("message", message); // set message
//		request.setAttribute("page_title", page_title );
//		request.setAttribute("addinstructions", AddInstructions);
		RequestDispatcher disp = request.getRequestDispatcher("index.jsp");
		disp.forward(request, response);
		return;
	}
	
	// drop the table
	private void dropTable() {
		boolean exists;
		try {
			if(db.tableExists(movie_table)) {
				System.out.println("Movie table exists, dropping...");
				exists = true;
				db.dropTable(movie_table);
				//md = new MovieDAO(db);
				md.create(); // re-create the Table
				
			}else {
				System.out.println("\n*** Table doesn't exist");
				//MovieDAO md = new MovieDAO(db);
				md.create();
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
