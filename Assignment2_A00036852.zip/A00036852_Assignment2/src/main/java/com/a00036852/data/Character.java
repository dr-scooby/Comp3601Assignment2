/**
 * Bean: Character in the movie
 */
package com.a00036852.data;

/**
 * @author Jahangir Ismail
 *
 */
public class Character {
	
	private String name;
	
	private String type; // type of character, Jedi, or Sith, bad or good
	
	private String weaponofchoice;
	
	private String planet; // planet location of character
	
	private String abilities;
	
	/**
	 * default Constructor
	 */
	public Character() {
		
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the weaponofchoice
	 */
	public String getWeaponofchoice() {
		return weaponofchoice;
	}

	/**
	 * @param weaponofchoice the weaponofchoice to set
	 */
	public void setWeaponofchoice(String weaponofchoice) {
		this.weaponofchoice = weaponofchoice;
	}

	/**
	 * @return the planet
	 */
	public String getPlanet() {
		return planet;
	}

	/**
	 * @param planet the planet to set
	 */
	public void setPlanet(String planet) {
		this.planet = planet;
	}

	/**
	 * @return the abilities
	 */
	public String getAbilities() {
		return abilities;
	}

	/**
	 * @param abilities the abilities to set
	 */
	public void setAbilities(String abilities) {
		this.abilities = abilities;
	}

	
}
