/**
 * Bean: Movie
 */
package com.a00036852.data;

/**
 * @author Jahangir Ismail
 *
 */
public class Movie {
	
	private int id;
	
	private String title;
	
	private String yearofrelease;
	
	private String runtime;
	
	private String story;
	
	/**
	 * default constructor
	 */
	public Movie() {
		
		title = "";
		
		yearofrelease = "";
		
		id = 0;
		
		runtime = "";
		
		story = "";
	}

	/**
	 * 
	 * @param title String
	 * @param yearofrelease String
	 * @param runtime String
	 * @param story String
	 */
	public Movie(String title, String yearofrelease, String runtime, String story) {
		this.title = title;
		this.yearofrelease = yearofrelease;
		this.runtime = runtime;
		this.story = story;
	}
	
	/**
	 * @return the story
	 */
	public String getStory() {
		return story;
	}


	/**
	 * @param story the story to set
	 */
	public void setStory(String story) {
		this.story = story;
	}


	public Movie(String t, String y) {
		this();
		this.title = t;
		this.yearofrelease = y;
	}

	/**
	 * @return the runtime
	 */
	public String getRuntime() {
		return runtime;
	}


	/**
	 * @param runtime the runtime to set
	 */
	public void setRuntime(String runtime) {
		this.runtime = runtime;
	}


	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}


	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}


	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}


	/**
	 * @return the yearofrelease
	 */
	public String getYearofrelease() {
		return yearofrelease;
	}


	/**
	 * @param yearofrelease the yearofrelease to set
	 */
	public void setYearofrelease(String yearofrelease) {
		this.yearofrelease = yearofrelease;
	}
	
	
	

}
